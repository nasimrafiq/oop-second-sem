using System;
namespace ShowRoomManagement
{
	public class OrderItemModel
	{
		private string name;
		private float purchasePrice;
		private float salePrice;   // ya price discount kay baad wali h
		private float discount;
		private int quantity;

		// ya car ki deep copy h, matlab car baad main change ho jaye to purana order change nahi ho ga
		public OrderItemModel(string name, float purchasePrice, float salePrice, float discount, int quantity)
		{
			this.name = name;
			this.purchasePrice = purchasePrice;
			this.salePrice = salePrice;
			this.discount = discount;
			this.quantity = quantity;
		}


		public string GetName() { return this.name; }

		public float GetPurchasePrice() { return this.purchasePrice; }

		public float GetSalePrice() { return this.salePrice; }

		public float GetDiscount() { return this.discount; }

		public int GetQuantity() { return this.quantity; }

		public float GetTotal() { return this.salePrice * this.quantity; }

		public override string ToString()
		{
			return $"{name},{purchasePrice},{salePrice},{discount},{quantity}";
		}
	}
}
