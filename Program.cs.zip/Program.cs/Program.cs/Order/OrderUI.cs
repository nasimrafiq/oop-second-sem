using System;
namespace ShowRoomManagement
{
	public class OrderUI
	{
		OrderService service = new OrderService();


		// ya Create New Sale wala option h, ya aik hi dafa chalta h aur phir main menu pay wapis
		public void OrderDriver()
		{
			Console.Clear();
			CreateNewSale();
			Console.ReadKey();
		}


		public void HistoryDriver()
		{
			while (true)
			{
				Console.Clear();
				string option = HistoryMenu();
				if (option == "1")
				{
					DisplayAllOrders();
				}
				else if (option == "2")
				{
					DisplayOrdersByCustomer();
				}
				else if (option == "3")
				{
					break;
				}
				else
				{
					Console.WriteLine("Wrong option selected!");
					Console.ReadKey();
				}
			}
		}



		public void CreateNewSale()
		{
			Console.WriteLine("Enter Customer name ");
			string customerName = Console.ReadLine();

			CustomerModel customer = service.SearchCustomer(customerName);
			if (customer == null)
			{
				Console.WriteLine("Customer not found, please enter the new customer details");
				customer = TakeCustomerInput(customerName);
				service.SaveCustomer(customer);
			}
			else
			{
				Console.WriteLine("Customer found");
				Console.WriteLine(customer.ToString());
			}

			OrderModel order = new OrderModel(customer);

			while (true)
			{
				Console.WriteLine("Enter Car name (type done to finish the order) ");
				string carName = Console.ReadLine();
				if (carName == "done")
				{
					break;
				}

				CarModel car = service.SearchCar(carName);
				if (car == null)
				{
					Console.WriteLine("Product not found");
				}
				else
				{
					Console.WriteLine("Sale Price: " + (car.GetSalePrice() + car.GetDiscount()));
					Console.WriteLine("Purchase Price: " + car.GetPurchasePrice());
					Console.WriteLine("Discount: " + car.GetDiscount());
					Console.WriteLine("Enter the quantity ");
					int quantity = int.Parse(Console.ReadLine());

					OrderItemModel item = new OrderItemModel(car.GetName(), car.GetPurchasePrice(), car.GetSalePrice(), car.GetDiscount(), quantity);
					order.AddItem(item);
					Console.WriteLine("Product added to the order");
				}
			}

			if (order.GetItems().Count == 0)
			{
				Console.WriteLine("No product added, order is not created");
			}
			else
			{
				service.SaveOrder(order);
				Console.WriteLine("Order created successfully");
				DisplayOrder(order);
			}
		}



		public void DisplayAllOrders()
		{
			List<OrderModel> orders = service.GetAllOrders();
			if (orders.Count == 0)
			{
				Console.WriteLine("No orders found");
			}
			foreach (OrderModel order in orders)
			{
				DisplayOrder(order);
			}
			Console.ReadKey();
		}


		public void DisplayOrdersByCustomer()
		{
			Console.WriteLine("Enter the Customer name ");
			string name = Console.ReadLine();

			List<OrderModel> orders = service.SearchOrdersByCustomerName(name);
			if (orders.Count == 0)
			{
				Console.WriteLine("No orders found");
			}
			else
			{
				Console.WriteLine("Total orders placed: " + orders.Count);
			}
			foreach (OrderModel order in orders)
			{
				DisplayOrder(order);
			}
			Console.ReadKey();
		}


		public void DisplayOrder(OrderModel order)
		{
			Console.WriteLine("--------------------------------");
			Console.WriteLine("Customer Name : " + order.GetCustomer().GetName());
			Console.WriteLine("Phone Number  : " + order.GetCustomer().GetPhoneNumber());
			Console.WriteLine("Age           : " + order.GetCustomer().GetAge());
			Console.WriteLine("Address       : " + order.GetCustomer().GetAddress());
			Console.WriteLine("Products Purchased:");
			foreach (OrderItemModel item in order.GetItems())
			{
				Console.WriteLine(item.GetName() + "  Price: " + item.GetSalePrice() + "  Quantity: " + item.GetQuantity() + "  Total: " + item.GetTotal());
			}
			Console.WriteLine("Total Bill    : " + order.GetTotalBill());
			Console.WriteLine("--------------------------------");
		}



		public CustomerModel TakeCustomerInput(string name)

		{
			Console.WriteLine("Enter Customer Phone Number");
			string phoneNumber = Console.ReadLine();
			Console.WriteLine("Enter Customer Age ");
			int age = int.Parse(Console.ReadLine());
			Console.WriteLine("Enter Customer Address ");
			string address = Console.ReadLine();

			CustomerModel customer = new CustomerModel(name, phoneNumber, age, address);
			return customer;
		}


		public string HistoryMenu()
		{
			Console.WriteLine("================================");
			Console.WriteLine("       View Order History       ");
			Console.WriteLine("================================");
			Console.WriteLine("1. View All Orders");
			Console.WriteLine("2. View Orders by Customer Name");
			Console.WriteLine("3. Back To Main ");
			string option = Console.ReadLine();
			return option;
		}
	}
}
