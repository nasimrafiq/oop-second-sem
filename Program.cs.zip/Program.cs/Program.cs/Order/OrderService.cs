using System;
namespace ShowRoomManagement
{
	public class OrderService
	{
		private OrderRepo _repo = new OrderRepo();
		private CustomerService _customerService = new CustomerService();
		private CarService _carService = new CarService();



		public OrderService() { }



		public CustomerModel SearchCustomer(string name)
		{
			return _customerService.SearchByName(name);
		}


		public void SaveCustomer(CustomerModel customer)
		{
			_customerService.SaveCustomer(customer);
		}


		public CarModel SearchCar(string name)
		{
			return _carService.SearchByName(name);
		}


		public void SaveOrder(OrderModel order)
		{
			_repo.SaveInFile(order);
		}


		public List<OrderModel> GetAllOrders()
		{
			return _repo.GetOrdersFromFile();
		}


		// ya function sab orders main say sirf us customer kay orders nikal kar naye list main daita h
		public List<OrderModel> SearchOrdersByCustomerName(string name)
		{
			List<OrderModel> found = new List<OrderModel>();
			foreach (OrderModel order in _repo.GetOrdersFromFile())
			{
				if (order.GetCustomer().GetName() == name)
				{
					found.Add(order);
				}
			}
			return found;
		}


	}
}
