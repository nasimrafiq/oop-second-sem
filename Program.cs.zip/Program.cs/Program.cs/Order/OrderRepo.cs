using System;
namespace ShowRoomManagement
{
	public class OrderRepo
	{
		private readonly string file = "orders.txt";


		public OrderRepo()
		{

		}

		// ya function naya order file main save karay ga

		public void SaveInFile(OrderModel order)
		{
			using (StreamWriter stream = new StreamWriter(file, true))
			{
				stream.WriteLine(order.ToString());
			}
		}


		// ya function file ki har line say customer aur uskay products nikal kar order bana kar list main add karta h
		// aur phir list return kar daita

		public List<OrderModel> GetOrdersFromFile()
		{
			List<OrderModel> ordersList = new List<OrderModel>();
			if (!File.Exists(file))
			{
				return ordersList;
			}
			using (StreamReader stream = new StreamReader(file))
			{
				string line = "";
				while ((line = stream.ReadLine()) != null)
				{
					string[] sections = line.Split('|');

					string[] c = sections[0].Split(',', 4);
					CustomerModel customer = new CustomerModel(c[0], c[1], int.Parse(c[2]), c[3]);
					OrderModel order = new OrderModel(customer);

					string[] itemParts = sections[1].Split(';', StringSplitOptions.RemoveEmptyEntries);
					foreach (string itemPart in itemParts)
					{
						string[] p = itemPart.Split(',');
						OrderItemModel item = new OrderItemModel(p[0], float.Parse(p[1]), float.Parse(p[2]), float.Parse(p[3]), int.Parse(p[4]));
						order.AddItem(item);
					}
					ordersList.Add(order);
				}
			}
			return ordersList;
		}
	}
}
