using System;
namespace ShowRoomManagement
{
	public class OrderModel
	{
		private CustomerModel customer;
		private List<OrderItemModel> items = new List<OrderItemModel>();

		// ya customer ki bhi deep copy bana raha h taake baad main customer update ho to purana order change na ho
		public OrderModel(CustomerModel customer)
		{
			this.customer = new CustomerModel(customer.GetName(), customer.GetPhoneNumber(), customer.GetAge(), customer.GetAddress());
		}


		public CustomerModel GetCustomer() { return this.customer; }

		public List<OrderItemModel> GetItems() { return this.items; }

		public void AddItem(OrderItemModel item) { this.items.Add(item); }

		public float GetTotalBill()
		{
			float total = 0;
			foreach (OrderItemModel item in items)
			{
				total = total + item.GetTotal();
			}
			return total;
		}

		// aik order aik line main save ho ga, customer ka data | kay pehlay aur products ; say alag alag
		public override string ToString()
		{
			string line = customer.ToString() + "|";
			foreach (OrderItemModel item in items)
			{
				line = line + item.ToString() + ";";
			}
			return line;
		}
	}
}
