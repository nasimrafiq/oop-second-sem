using System;
namespace ShowRoomManagement
{
	public class CustomerService
	{
		private CustomerRepo _repo = new CustomerRepo();



		public CustomerService() { }



		public List<CustomerModel> GetAllData()
		{
			return _repo.GetCustomersFromFile();
		}


		public void SaveCustomer(CustomerModel customer)
		{
			_repo.SaveInFile(customer);
		}


		public CustomerModel SearchByName(string name)
		{
			foreach (CustomerModel customer in _repo.GetCustomersFromFile())
			{
				if (customer.GetName() == name)
				{
					return customer;
				}
			}
			return null;
		}



		// ya function getcustomersfromfile say sab customers ko customers main load karay ga phir loop chalay ga
		public bool UpdateCustomer(string name, string phoneNumber, int age, string address)
		{
			List<CustomerModel> customers = _repo.GetCustomersFromFile();
			foreach (CustomerModel customer in customers)
			{
				if (customer.GetName() == name)
				{
					customer.SetPhoneNumber(phoneNumber);
					customer.SetAge(age);
					customer.SetAddress(address);
					_repo.SaveAllDataIntoFile(customers);
					return true;
				}
			}
			return false;
		}


		public bool DeleteByName(string name)
		{
			List<CustomerModel> customers = _repo.GetCustomersFromFile();
			int count = 0;
			foreach (CustomerModel customer in customers)
			{
				if (customer.GetName() == name)
				{
					customers.RemoveAt(count);
					_repo.SaveAllDataIntoFile(customers);
					return true;
				}
				count++;
			}
			return false;
		}


	}
}
