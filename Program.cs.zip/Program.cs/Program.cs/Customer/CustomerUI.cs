using System;
namespace ShowRoomManagement
{
	public class CustomerUI
	{
		CustomerService service = new CustomerService();


		public void CustomerDriver()
		{
			while (true)
			{
				Console.Clear();
				string option = CustomerMenu();
				if (option == "1")
				{
					AddCustomer();
				}
				else if (option == "2")
				{
					UpdateCustomer();
				}
				else if (option == "3")
				{
					DeleteCustomer();
				}
				else if (option == "4")
				{
					DisplayAll();
				}
				else if (option == "5")
				{
					break;
				}
				else
				{
					Console.WriteLine("Wrong option selected!");
					Console.ReadKey();
				}
			}
		}


		public void AddCustomer()
		{
			CustomerModel customer = TakeInput();
			if (service.SearchByName(customer.GetName()) != null)
			{
				Console.WriteLine("Customer already exists!");
			}
			else
			{
				service.SaveCustomer(customer);
				Console.WriteLine("Customer added successfully");
			}
			Console.ReadKey();
		}


		public void UpdateCustomer()
		{
			Console.WriteLine("Enter the Customer name which you want to update");
			string name = Console.ReadLine();
			Console.WriteLine("Enter the new Phone Number");
			string phoneNumber = Console.ReadLine();
			Console.WriteLine("Enter the new Age");
			int age = int.Parse(Console.ReadLine());
			Console.WriteLine("Enter the new Address");
			string address = Console.ReadLine();

			if (service.UpdateCustomer(name, phoneNumber, age, address))
			{
				Console.WriteLine("Customer updated successfully");
			}
			else
			{
				Console.WriteLine("Customer not found");
			}
			Console.ReadKey();
		}


		public void DeleteCustomer()
		{
			Console.WriteLine("Enter the Customer name which you want to delete");
			string name = Console.ReadLine();

			if (service.DeleteByName(name))
			{
				Console.WriteLine("Customer deleted successfully");
			}
			else
			{
				Console.WriteLine("Customer not found");
			}
			Console.ReadKey();
		}



		public void DisplayAll()
		{
			List<CustomerModel> customers = service.GetAllData();
			foreach (CustomerModel c in customers)
			{
				Console.WriteLine(c.ToString());
			}
			Console.ReadKey();
		}



		public CustomerModel TakeInput()

		{
			Console.WriteLine("Enter Customer name ");
			string name = Console.ReadLine();
			Console.WriteLine("Enter Customer Phone Number");
			string phoneNumber = Console.ReadLine();
			Console.WriteLine("Enter Customer Age ");
			int age = int.Parse(Console.ReadLine());
			Console.WriteLine("Enter Customer Address ");
			string address = Console.ReadLine();

			CustomerModel customer = new CustomerModel(name, phoneNumber, age, address);
			return customer;
		}


		public string CustomerMenu()
		{
			Console.WriteLine("================================");
			Console.WriteLine("      Customer Management       ");
			Console.WriteLine("================================");
			Console.WriteLine("1. Add Customer");
			Console.WriteLine("2. Update Customer");
			Console.WriteLine("3. Delete Customer");
			Console.WriteLine("4. View All Customers");
			Console.WriteLine("5. Back To Main ");
			string option = Console.ReadLine();
			return option;
		}
	}
}
