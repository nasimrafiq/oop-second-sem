using System;
namespace ShowRoomManagement
{
	public class CustomerRepo
	{
		private readonly string file = "customer.txt";


		public CustomerRepo()
		{

		}

		// ya wo function h jab hum user say aik aik customer ka data lain gay aur ya file main save karay ga

		public void SaveInFile(CustomerModel customer)
		{
			using (StreamWriter stream = new StreamWriter(file, true))
			{
				stream.WriteLine(customer.ToString());
			}
		}

		// ya function tab use ho ga jab hum list main update karain gay data ko

		public void SaveAllDataIntoFile(List<CustomerModel> customers)
		{
			File.WriteAllText(file, string.Empty);
			foreach (CustomerModel customer in customers)
			{
				SaveInFile(customer);
			}
		}


		// ya pehlay list create karta h phir saray data ko variables main put karta phir un sab ko list main add karta
		// aur phir list return kar daita

		public List<CustomerModel> GetCustomersFromFile()
		{
			List<CustomerModel> customersList = new List<CustomerModel>();
			if (!File.Exists(file))
			{
				return customersList;
			}
			using (StreamReader stream = new StreamReader(file))
			{
				string line = "";
				while ((line = stream.ReadLine()) != null)
				{
					string[] parts = line.Split(',', 4);
					string name = parts[0];
					string phoneNumber = parts[1];
					int age = int.Parse(parts[2]);
					string address = parts[3];
					CustomerModel customerModel = new CustomerModel(name, phoneNumber, age, address);
					customersList.Add(customerModel);
				}
			}
			return customersList;
		}
	}
}
