﻿using System;
namespace ShowRoomManagement
{
    public class Shop
    {


        public void Start()
        {
            while (true)
            {
                Console.Clear();
                string option = MainMenu();
                if (option == "1")
                {
                    CarUI carUI = new CarUI();
                    carUI.CarDriver();
                }
                else if (option == "2")
                {
                    CustomerUI customerUI = new CustomerUI();
                    customerUI.CustomerDriver();
                }
                else if (option == "3")
                {
                    OrderUI orderUI = new OrderUI();
                    orderUI.OrderDriver();
                }
                else if (option == "4")
                {
                    OrderUI orderUI = new OrderUI();
                    orderUI.HistoryDriver();
                }
                else if (option == "5")
                {
                    break;
                }
            }
        }


		public String MainMenu()
		{
			Console.WriteLine("================================");
            Console.WriteLine("   ShowRoom Management System   ");
            Console.WriteLine("================================");
            Console.WriteLine("1. Product Managing");
            Console.WriteLine("2. Customer Namaging");
            Console.WriteLine("3. Order Managing");
            Console.WriteLine("4. To View Order History");
            Console.WriteLine("5. Exit ");
			string option = Console.ReadLine();
			return option;

        }
	}
}

