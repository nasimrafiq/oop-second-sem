﻿using System;
namespace ShowRoomManagement
{
	public class CarModel
	{
		private string name;
		private string description;
		private float purchasePrice;
		private float salePrice;
		private float discount;

		public CarModel(string name, string description, float purchasePrice, float salePrice, float discount)
		{
			this.name = name;
			this.description = description;
			this.purchasePrice = purchasePrice;
			this.salePrice = salePrice;
			this.discount = discount;
		}


		public void SetName(string name)  { this.name = name; }
		public string GetName() { return this.name; }

		public void SetDescription(string description) { this.description = description; }
		public string GetDescription() { return this.description; }
		
		public void SetPurchaseprice( float price) { this.purchasePrice = price; }
		public float GetPurchasePrice() { return this.purchasePrice;  }

		public void SetSalePrice ( float price) { this.salePrice = price; }
		public float GetSalePrice() { return this.salePrice - discount; }

		public float GetDiscount() { return this.discount; }

        public override string ToString()
        {
            return $"{name},{description},{purchasePrice},{salePrice},{discount}";
        }
    }
}

