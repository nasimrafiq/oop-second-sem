﻿ using System;
namespace ShowRoomManagement
{
	public class CarRepo
	{
		private readonly string file = "car.txt";


		public CarRepo ()
		{

		}

        // ya wo function h jab hum user say aik aik product ka data lain gay aur ya file main save karay ga

		public void SaveInFile (CarModel car)
		{
			using (StreamWriter stream = new StreamWriter (file , true ))
			{
				stream.Write(car.ToString())  ;
			}
		}

		// ya function tab use ho ga jab hum list main updtae karain gay data ko 
     
		public void SaveAllDataIntoFile(List<CarModel> cars )
		{
			File.WriteAllText(file, string.Empty);
			foreach (CarModel car in cars )
			{
				SaveInFile(car); 
			}
		}



        // ya pehlay list create karta h phir saray data ko variables main put karta phir un sab ko list main add karta
		// aur phir list return kar daita


		public List<CarModel> GetProductsFromFile()
		{
			List<CarModel> carsLists = new List<CarModel>();
			using (StreamReader stream = new StreamReader(file))
			{
				string line = "";
				while ((line = stream.ReadLine()) != null)
				{
					string[] parts = line.Split(',');
					string name = parts[0];
					string description = parts[1];
					float  purchasePrice = float.Parse(parts[2]);
					float salePrice = float.Parse(parts[3]);
					float discount = float.Parse(parts[4]);
					CarModel carModel = new CarModel(name , description, purchasePrice , salePrice, discount);
					carsLists.Add(carModel);

				}
			}
			return carsLists;
		}
	}
}

