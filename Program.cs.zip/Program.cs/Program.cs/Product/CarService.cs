﻿using System;
namespace ShowRoomManagement
{
	public class CarService
	{
		private CarRepo _repo = new CarRepo();




		public CarService() { }



        public List<CarModel> GetAllData()
        {
            return _repo.GetProductsFromFile();
        }


        public void SaveCar(CarModel car)
        {
            _repo.SaveInFile(car); 
        }


		public CarModel SearchByName( string name)
		{
			foreach (CarModel car in _repo.GetProductsFromFile())
			{
				if (car.GetName() == name)
				{
					return car;
				}
			}
			return null; 
		}



		// ya function getproductsfromfile say sab products ko products main load karay ga phir loop chalay ga 
		public bool  UpdateCarPrice (string name , float salePrice)
		{
			List<CarModel> cars = _repo.GetProductsFromFile();
            foreach (CarModel car in cars)
            {
                if (car.GetName() == name)
                {
                    car .SetSalePrice (salePrice);
                    _repo.SaveAllDataIntoFile(cars);
					return true;
                }
            }
			return false;
        }


        public bool DeleteByName(string name)
        {
            List<CarModel> cars = _repo.GetProductsFromFile();
            int count = 0;
            foreach (CarModel car in cars)
            {
                if (car.GetName() == name)
                {
                    cars.RemoveAt(count);
                    _repo.SaveAllDataIntoFile(cars);
                    return true;
                }
                count++;
            }
            return false;
        }


    }
}

