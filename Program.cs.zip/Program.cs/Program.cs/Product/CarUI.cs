﻿using System;
namespace ShowRoomManagement
{
	public class CarUI
	{
        CarService service = new CarService();


        public void CarDriver()
        {
            while (true)
            {
                Console.Clear(); 
                string option = CarMenu();
                if (option == "1")
                {
                    CarModel car = TakeInput();
                    service.SaveCar(car); 
                }
                else if (option == "2")
                {
                    UpdateCar();
                }
                else if (option == "3")
                {
                    DeleteCar();
                }
                else if (option == "4")
                {
                    DisplayAll();
                }
                else if (option == "5")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Wrong option selected!");
                }
            }
        }



        public void UpdateCar()
        {
            Console.WriteLine("Enter the Car name which you want to update");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Car price");
            float price = float.Parse(Console.ReadLine());

            service.UpdateCarPrice(name, price); 
        }


        public void DeleteCar()
        {
            Console.WriteLine("Enter the Car name which you want to delete");
            string name = Console.ReadLine();
        

            service.DeleteByName(name);
        }



        public void DisplayAll()
        {
            List<CarModel> cars = service.GetAllData();
            foreach (CarModel p in cars)
            {
                Console.WriteLine(p.ToString());
            }
            Console.ReadKey();
        }



        public CarModel TakeInput()

        {
            Console.WriteLine("Enter Car name ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Car Description");
            string description = Console.ReadLine();
            Console.WriteLine("Enter Car Purchase Price ");
            float purchasePrice = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Car sale price  ");
            float salePrice = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter discount on the Car ");
            float discount = float.Parse(Console.ReadLine());

            CarModel car  = new CarModel (name, description, purchasePrice, salePrice, discount);
            return car; 
        }


		public string CarMenu()
		{
            Console.WriteLine("================================");
            Console.WriteLine("       Car     Management       ");
            Console.WriteLine("================================");
            Console.WriteLine("1. Add Car");
            Console.WriteLine("2. Update Car");
            Console.WriteLine("3. Delete Car");
            Console.WriteLine("4. View All Cars");
            Console.WriteLine("5. Back To Main ");
            string option = Console.ReadLine();
            return option;
        }
	}
}

